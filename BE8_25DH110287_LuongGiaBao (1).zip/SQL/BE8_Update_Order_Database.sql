USE MyStore;
GO

IF COL_LENGTH('dbo.[Order]', 'DeliveryMethod') IS NULL
    ALTER TABLE dbo.[Order] ADD DeliveryMethod NVARCHAR(100) NULL;
GO

IF COL_LENGTH('dbo.[Order]', 'PaymentMethod') IS NULL
    ALTER TABLE dbo.[Order] ADD PaymentMethod NVARCHAR(100) NULL;
GO

IF COL_LENGTH('dbo.[Order]', 'ShippingAddress') IS NULL
BEGIN
    IF COL_LENGTH('dbo.[Order]', 'AddressDelivery') IS NOT NULL
        EXEC sp_rename 'dbo.[Order].AddressDelivery', 'ShippingAddress', 'COLUMN';
    ELSE
        ALTER TABLE dbo.[Order] ADD ShippingAddress NVARCHAR(500) NULL;
END
GO

IF COL_LENGTH('dbo.OrderDetail', 'TotalPrice') IS NULL
    ALTER TABLE dbo.OrderDetail
    ADD TotalPrice AS (Quantity * UnitPrice) PERSISTED;
GO
