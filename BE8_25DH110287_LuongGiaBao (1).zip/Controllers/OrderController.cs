using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using MaSV_MyStore.Models;
using MaSV_MyStore.Models.ViewModel;

namespace MaSV_MyStore.Controllers
{
    [Authorize]
    public class OrderController : Controller
    {
        private MyStoreEntities db = new MyStoreEntities();

        [HttpGet]
        public ActionResult Checkout()
        {
            var cart = Session["Cart"] as List<CartItem>;
            if (cart == null || !cart.Any())
                return RedirectToAction("Index", "Home");

            var username = User.Identity.Name;
            var customer = db.Customers.SingleOrDefault(c => c.Username == username);
            if (customer == null)
                return RedirectToAction("ProfileInfo", "Account");

            var model = new CheckoutVM
            {
                ShippingAddress = customer.Address,
                FullName = customer.FullName,
                Phone = customer.Phone,
                Email = customer.Email,
                DeliveryMethod = "Giao hàng tiêu chuẩn",
                PaymentMethod = "Thanh toán khi nhận hàng",
                Items = cart,
                TotalAmount = cart.Sum(x => x.Quantity * x.UnitPrice)
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Checkout(CheckoutVM model)
        {
            var cart = Session["Cart"] as List<CartItem>;
            if (cart == null || !cart.Any())
                return RedirectToAction("Index", "Home");

            var username = User.Identity.Name;
            var customer = db.Customers.SingleOrDefault(c => c.Username == username);
            if (customer == null)
                return RedirectToAction("ProfileInfo", "Account");

            model.Items = cart;
            model.TotalAmount = cart.Sum(x => x.Quantity * x.UnitPrice);

            if (!ModelState.IsValid)
            {
                model.FullName = customer.FullName;
                model.Phone = customer.Phone;
                model.Email = customer.Email;
                return View(model);
            }

            if (String.IsNullOrWhiteSpace(model.ShippingAddress))
            {
                ModelState.AddModelError("ShippingAddress", "Vui lòng nhập địa chỉ giao hàng.");
                return View(model);
            }

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    var order = new Order
                    {
                        Username = username,
                        OrderDate = DateTime.Now,
                        TotalAmount = model.TotalAmount,
                        PaymentStatus = "Pending",
                        DeliveryMethod = model.DeliveryMethod,
                        PaymentMethod = model.PaymentMethod,
                        ShippingAddress = model.ShippingAddress
                    };

                    db.Orders.Add(order);
                    db.SaveChanges();

                    foreach (var item in cart)
                    {
                        var detail = new OrderDetail
                        {
                            OrderID = order.OrderID,
                            ProductID = item.ProductID,
                            Quantity = item.Quantity,
                            UnitPrice = item.UnitPrice
                        };
                        db.OrderDetails.Add(detail);
                    }

                    db.SaveChanges();
                    transaction.Commit();

                    Session["Cart"] = null;
                    return RedirectToAction("OrderSuccess", new { OrderID = order.OrderID });
                }
                catch
                {
                    transaction.Rollback();
                    ModelState.AddModelError("", "Không thể lưu đơn hàng. Vui lòng kiểm tra cấu trúc database.");
                    model.Items = cart;
                    return View(model);
                }
            }
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult OrderSuccess(int? OrderID)
        {
            if (!OrderID.HasValue)
                return RedirectToAction("Index", "Home");

            var order = db.Orders
                .Include(o => o.OrderDetails.Select(d => d.Product))
                .SingleOrDefault(o => o.OrderID == OrderID.Value);

            if (order == null)
                return HttpNotFound();

            if (User.Identity.IsAuthenticated && order.Username != User.Identity.Name)
                return new HttpUnauthorizedResult();

            return View(order);
        }

        public ActionResult MyOrder()
        {
            var username = User.Identity.Name;
            var orders = db.Orders
                .Include(o => o.OrderDetails.Select(d => d.Product))
                .Where(o => o.Username == username)
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            return View(orders);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
