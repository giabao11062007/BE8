function enableAddressEdit() {
    var oldAddress = document.getElementById("ShippingAddress");
    var newAddress = document.getElementById("newShippingAddress");
    newAddress.value = oldAddress.value;
    newAddress.classList.remove("be8-hidden");
    oldAddress.setAttribute("readonly", "readonly");
    newAddress.focus();
}
function updateShippingAddress() {
    var oldAddress = document.getElementById("ShippingAddress");
    var newAddress = document.getElementById("newShippingAddress");
    if (newAddress && newAddress.value.trim() !== "") {
        oldAddress.value = newAddress.value.trim();
    }
}
