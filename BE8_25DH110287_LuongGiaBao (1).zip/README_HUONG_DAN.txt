BE8 - CUSTOMER SITE: ĐẶT HÀNG - XÁC NHẬN ĐƠN HÀNG
Gói mã nguồn bổ sung cho ASP.NET MVC 5 + Entity Framework 6 + SQL Server.

LƯU Ý QUAN TRỌNG
Bạn chỉ gửi slide hướng dẫn và ảnh đề bài, chưa gửi project Visual Studio hiện tại hoặc database/EDMX.
Vì vậy gói này là bộ mã nguồn để tích hợp vào project MVC5 hiện có, không phải project đã kết nối sẵn database và không thể bảo đảm chạy ngay nếu tên bảng/cột trong EDMX của bạn khác.
Các tên entity/cột bên dưới bám theo slide: MyStoreEntities, Users, Customers, Orders, OrderDetails, Products.

CẤU TRÚC
- Controllers/OrderController.cs: Checkout, OrderSuccess, MyOrder.
- Models/ViewModel/CheckoutVM.cs: dữ liệu form thanh toán.
- Views/Order/Checkout.cshtml: form đặt hàng.
- Views/Order/OrderSuccess.cshtml: xác nhận đơn hàng và chi tiết.
- Views/Order/MyOrder.cshtml: lịch sử mua hàng.
- SQL/BE8_Update_Order_Database.sql: cập nhật bảng Order/OrderDetail theo slide.
- Web.config.snippet: cấu hình Forms Authentication.
- Content/myStyle/BE8_Order.css: giao diện.
- Scripts/BE8_Order.js: chỉnh địa chỉ giao hàng.

CÁCH TÍCH HỢP TRONG VISUAL STUDIO
1. Mở solution ASP.NET MVC 5 hiện tại bằng Visual Studio.
2. Giải nén ZIP. Chép các thư mục Controllers, Models, Views, Content, Scripts vào project; chọn Include In Project nếu Visual Studio chưa tự nhận.
3. Đổi namespace "MaSV_MyStore" trong các file .cs/.cshtml thành namespace Models/Project thực tế của bạn.
4. Kiểm tra EDMX có các entity User, Customer, Order, OrderDetail, Product và các navigation property tương ứng.
5. Chạy SQL/BE8_Update_Order_Database.sql trên đúng database MyStore. Nếu cột đã tồn tại thì bỏ qua phần ALTER tương ứng.
6. Nếu dùng Database First: mở file .edmx > Update Model from Database > Refresh các bảng Order và OrderDetail > Finish.
7. Đảm bảo Session được bật. CartController/giỏ hàng phải lưu Session["Cart"] dưới dạng List<CartItem> với các thuộc tính ProductID, ProductName, ProductImage, Quantity, UnitPrice.
8. Đảm bảo đăng nhập dùng Forms Authentication và User.Identity.Name trả về Username.
9. Kiểm tra tên thuộc tính trong EDMX. Nếu khác, sửa các dòng truy cập property trong OrderController cho đúng schema.
10. Chạy thử: đăng nhập > thêm sản phẩm vào giỏ > mở /Order/Checkout > đặt hàng > xem /Order/OrderSuccess?OrderID=... > /Order/MyOrder.

CÁC GIẢ ĐỊNH CẦN ĐỐI CHIẾU VỚI DATABASE
Order: OrderID, Username, OrderDate, TotalAmount, PaymentStatus, DeliveryMethod, PaymentMethod, ShippingAddress.
OrderDetail: OrderDetailID, OrderID, ProductID, Quantity, UnitPrice, TotalPrice (computed).
Customer: Username, FullName, Phone, Email, Address.
Product: ProductID, ProductName, ProductImage.
Nếu database của bạn dùng CustomerID thay Username hoặc dùng tên cột khác, cần sửa controller theo EDMX thật.

PHẠM VI THEO SLIDE BE8
- Kiểm tra giỏ hàng trong Session["Cart"].
- Yêu cầu đăng nhập trước khi checkout.
- Lấy địa chỉ khách hàng và cho phép thay đổi địa chỉ giao hàng.
- Lưu Order và OrderDetail vào database.
- Xóa giỏ hàng sau khi lưu đơn thành công.
- Trang xác nhận hiển thị mã đơn, ngày đặt, tổng tiền, trạng thái thanh toán, phương thức thanh toán/giao hàng, địa chỉ và từng sản phẩm.
- Lịch sử đơn hàng của khách đang đăng nhập.
PayPal là phần optional theo slide, gói này dùng thanh toán khi nhận hàng/chuyển khoản thủ công, chưa tích hợp PayPal API.
